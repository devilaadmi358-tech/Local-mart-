import React, { useState, useMemo, useEffect } from 'react';
import {
  Store, ShoppingBag, ShieldCheck, MapPin, Search, Plus, Minus, Trash2,
  CheckCircle2, Clock, Truck, XCircle, ToggleLeft, ToggleRight, Package,
  Edit3, Eye, EyeOff, LogOut, DollarSign, Users, AlertTriangle, ChevronRight,
  Phone, ArrowLeft, Filter, Sparkles, RefreshCw, Layers, Lock, Check, X,
  Volume2, VolumeX, Navigation, Bell, Smartphone, Share2, Compass, Crosshair,
  Target, KeyRound, ShieldAlert, UserCheck, Tag, Percent, Zap, Award
} from 'lucide-react';

// --- HAVERSINE DISTANCE CALCULATOR ---
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return 0;
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(2));
}

// --- SYNTHESIZED WEB AUDIO API ALERT (SANDBOX SAFE) ---
function playOrderChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    const now = ctx.currentTime;

    // Tone 1: High crisp bell ping (880Hz -> A5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.exponentialRampToValueAtTime(440, now + 0.35);
    gain1.gain.setValueAtTime(0.35, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.45);

    // Tone 2: Warm harmony bell (1174Hz -> D6)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1174.66, now + 0.18);
    gain2.gain.setValueAtTime(0.35, now + 0.18);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.75);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.18);
    osc2.stop(now + 0.75);
  } catch (err) {
    console.warn('Audio synthesis note:', err);
  }
}

// --- INITIAL MULTI-TENANT SEED DATA WITH PASSWORDS & KANPUR COORDINATES ---
const INITIAL_STORES = [
  {
    id: 'store_1',
    name: 'Gupta Kirana & General Store',
    owner: 'Ramesh Gupta',
    phone: '+91 98390 11223',
    loginId: 'gupta@localmart.in',
    password: 'gupta123',
    area: 'Swaroop Nagar',
    pincode: '208002',
    lat: 26.4784,
    lng: 80.3205,
    radiusKm: 3.5,
    isOpen: true,
    isActive: true,
    plan: 'Pro Growth (₹1,499/mo)',
    billingStatus: 'Paid',
    rating: 4.8,
    deliveryEta: '15-20 mins',
    minOrder: 99,
    freeDeliveryThreshold: 199,
    category: 'Grocery & Daily Needs',
    activeSessions: 2
  },
  {
    id: 'store_2',
    name: 'Kanpur Fresh Dairy & Bakery',
    owner: 'Saurabh Verma',
    phone: '+91 94150 44556',
    loginId: 'dairy@localmart.in',
    password: 'dairy123',
    area: 'Kakadeo',
    pincode: '208025',
    lat: 26.4822,
    lng: 80.2948,
    radiusKm: 4.0,
    isOpen: true,
    isActive: true,
    plan: 'Starter (₹999/mo)',
    billingStatus: 'Paid',
    rating: 4.6,
    deliveryEta: '12-18 mins',
    minOrder: 79,
    freeDeliveryThreshold: 149,
    category: 'Dairy, Bread & Eggs',
    activeSessions: 1
  },
  {
    id: 'store_3',
    name: 'Nayaganj Spice & Dry Fruit Hub',
    owner: 'Anil Agarwal',
    phone: '+91 99350 77889',
    loginId: 'spice@localmart.in',
    password: 'spice123',
    area: 'Kidwai Nagar',
    pincode: '208011',
    lat: 26.4348,
    lng: 80.3342,
    radiusKm: 5.0,
    isOpen: false,
    isActive: true,
    plan: 'Pro Growth (₹1,499/mo)',
    billingStatus: 'Due',
    rating: 4.9,
    deliveryEta: '25-30 mins',
    minOrder: 199,
    freeDeliveryThreshold: 299,
    category: 'Spices, Oils & Dry Fruits',
    activeSessions: 1
  }
];

const INITIAL_RIDERS = [
  { id: 'r_1', name: 'Raju Yadav', phone: '+91 98391 10101', vehicle: 'Hero Splendor (UP-78-AB-4412)' },
  { id: 'r_2', name: 'Deepak Kumar', phone: '+91 98391 20202', vehicle: 'TVS Electric iQube (UP-78-CD-8890)' },
  { id: 'r_3', name: 'Aman Kushwaha', phone: '+91 98391 30303', vehicle: 'Bajaj Platina (UP-78-EF-1123)' },
  { id: 'r_4', name: 'Store Self-Delivery Staff', phone: '+91 98390 11223', vehicle: 'Store E-Rickshaw / Cycle' }
];

const INITIAL_PRODUCTS = [
  // Store 1 Products
  { id: 'p_101', storeId: 'store_1', name: 'Aashirvaad Shudh Chakki Atta (5 kg)', category: 'Staples & Atta', price: 245, mrp: 275, unit: '5 kg Pack', inStock: true, visible: true, stockQty: 42 },
  { id: 'p_102', storeId: 'store_1', name: 'Fortune Sunlite Refined Sunflower Oil', category: 'Oils & Ghee', price: 145, mrp: 165, unit: '1 L Pouch', inStock: true, visible: true, stockQty: 65 },
  { id: 'p_103', storeId: 'store_1', name: 'Tata Sampann Unpolished Toor Dal', category: 'Pulses & Dal', price: 168, mrp: 190, unit: '1 kg Pack', inStock: true, visible: true, stockQty: 28 },
  { id: 'p_104', storeId: 'store_1', name: 'Maggi 2-Minute Masala Noodles (4 Pack)', category: 'Snacks & Instant', price: 56, mrp: 60, unit: '280 g', inStock: true, visible: true, stockQty: 90 },
  { id: 'p_105', storeId: 'store_1', name: 'Red Label Natural Care Tea', category: 'Beverages', price: 260, mrp: 295, unit: '500 g', inStock: false, visible: true, stockQty: 0 },

  // Store 2 Products
  { id: 'p_201', storeId: 'store_2', name: 'Amul Taaza Homogenised Toned Milk', category: 'Milk & Curd', price: 54, mrp: 56, unit: '1 L Tetra', inStock: true, visible: true, stockQty: 110 },
  { id: 'p_202', storeId: 'store_2', name: 'Fresh Malai Paneer (Soft Block)', category: 'Milk & Curd', price: 95, mrp: 110, unit: '250 g', inStock: true, visible: true, stockQty: 24 },
  { id: 'p_203', storeId: 'store_2', name: 'Brown Whole Wheat Sandwich Bread', category: 'Bakery', price: 45, mrp: 50, unit: '400 g Loaf', inStock: true, visible: true, stockQty: 35 },
  { id: 'p_204', storeId: 'store_2', name: 'Amul Pasteurised Butter', category: 'Milk & Curd', price: 275, mrp: 285, unit: '500 g Pack', inStock: true, visible: true, stockQty: 19 },

  // Store 3 Products
  { id: 'p_301', storeId: 'store_3', name: 'California Almonds (Badam Giri)', category: 'Dry Fruits', price: 420, mrp: 500, unit: '500 g Pack', inStock: true, visible: true, stockQty: 30 },
  { id: 'p_302', storeId: 'store_3', name: 'Kachi Ghani Pure Mustard Oil', category: 'Oils & Ghee', price: 172, mrp: 195, unit: '1 L Bottle', inStock: true, visible: true, stockQty: 50 },
  { id: 'p_303', storeId: 'store_3', name: 'Catch Sabzi Masala & Garam Masala Combo', category: 'Whole Spices', price: 135, mrp: 160, unit: '2 x 100 g', inStock: true, visible: true, stockQty: 40 }
];

const INITIAL_ORDERS = [
  {
    id: 'ORD-8821',
    storeId: 'store_1',
    customerName: 'Harsh Tiwari',
    customerPhone: '+91 91234 56789',
    address: 'B-14, Near Moti Jheel, Swaroop Nagar, Kanpur (208002)',
    items: [
      { productId: 'p_101', name: 'Aashirvaad Shudh Chakki Atta (5 kg)', qty: 1, price: 245 },
      { productId: 'p_102', name: 'Fortune Sunlite Refined Sunflower Oil', qty: 2, price: 145 }
    ],
    total: 535,
    discount: 0,
    deliveryFee: 0,
    handlingFee: 5,
    riderTip: 10,
    deliveryInstructions: 'Leave at guard desk',
    deliveryOtp: '4829',
    rider: null,
    status: 'PENDING',
    createdAt: '2 mins ago',
    paymentMode: 'UPI Instant'
  },
  {
    id: 'ORD-8819',
    storeId: 'store_1',
    customerName: 'Priya Sharma',
    customerPhone: '+91 98765 43210',
    address: 'Flat 302, Emerald Residency, Arya Nagar, Kanpur (208002)',
    items: [
      { productId: 'p_103', name: 'Tata Sampann Unpolished Toor Dal', qty: 2, price: 168 },
      { productId: 'p_104', name: 'Maggi 2-Minute Masala Noodles (4 Pack)', qty: 1, price: 56 }
    ],
    total: 392,
    discount: 0,
    deliveryFee: 0,
    handlingFee: 5,
    riderTip: 0,
    deliveryInstructions: 'Ring doorbell',
    deliveryOtp: '7314',
    rider: INITIAL_RIDERS[0],
    status: 'PACKING',
    createdAt: '14 mins ago',
    paymentMode: 'Cash on Delivery'
  },
  {
    id: 'ORD-8814',
    storeId: 'store_2',
    customerName: 'Vikram Singh',
    customerPhone: '+91 88776 65544',
    address: 'Hostel Lane 4, Coaching Hub, Kakadeo, Kanpur (208025)',
    items: [
      { productId: 'p_201', name: 'Amul Taaza Homogenised Toned Milk', qty: 2, price: 54 },
      { productId: 'p_203', name: 'Brown Whole Wheat Sandwich Bread', qty: 1, price: 45 }
    ],
    total: 153,
    discount: 0,
    deliveryFee: 0,
    handlingFee: 5,
    riderTip: 20,
    deliveryInstructions: 'Call when reaching hostel gate',
    deliveryOtp: '9105',
    rider: INITIAL_RIDERS[1],
    status: 'DISPATCHED',
    createdAt: '22 mins ago',
    paymentMode: 'UPI Instant'
  }
];

const KANPUR_GPS_PRESETS = [
  { label: 'Swaroop Nagar (Near Moti Jheel)', lat: 26.4784, lng: 80.3205 },
  { label: 'Kakadeo (Deoki Cinema / Coaching)', lat: 26.4820, lng: 80.2950 },
  { label: 'Kidwai Nagar (South Kanpur Hub)', lat: 26.4350, lng: 80.3350 },
  { label: 'Civil Lines (Green Park / Mall)', lat: 26.4720, lng: 80.3450 },
  { label: 'Far Suburb / Unnao (Out of Radius)', lat: 26.5400, lng: 80.4900 }
];

const PROMO_COUPONS = [
  { code: 'KANPUR30', discount: 30, minSubtotal: 199, desc: 'Flat ₹30 OFF on orders above ₹199' },
  { code: 'FIRST50', discount: 50, minSubtotal: 299, desc: 'Flat ₹50 OFF on orders above ₹299' },
  { code: 'FREEDEL', discount: 15, minSubtotal: 99, desc: 'Waive ₹15 Instant Delivery Fee' }
];

const ORDER_STAGES = ['PENDING', 'ACCEPTED', 'PACKING', 'DISPATCHED', 'DELIVERED'];

export default function App() {
  // Primary Surface Switcher: 'customer' | 'shopkeeper' | 'admin'
  const [activeSurface, setActiveSurface] = useState('customer');

  // Shared Multi-Tenant State
  const [stores, setStores] = useState(INITIAL_STORES);
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [orders, setOrders] = useState(INITIAL_ORDERS);
  const [toast, setToast] = useState(null);

  // --- AUTHENTICATION & PASSWORD PROTECTION STATE ---
  // Shopkeeper Auth: tracks which store_id is currently unlocked
  const [authenticatedStoreId, setAuthenticatedStoreId] = useState(null);
  const [merchantLoginStoreId, setMerchantLoginStoreId] = useState('store_1');
  const [merchantPasswordInput, setMerchantPasswordInput] = useState('');
  const [merchantAuthError, setMerchantAuthError] = useState('');
  const [newMerchantPassInput, setNewMerchantPassInput] = useState('');

  // Super-Admin Auth
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminEmailInput, setAdminEmailInput] = useState('admin@localmart.in');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminMasterPassword, setAdminMasterPassword] = useState('admin@kanpur2026');
  const [adminAuthError, setAdminAuthError] = useState('');
  const [newAdminPassInput, setNewAdminPassInput] = useState('');

  // Admin Reset Store Password Modal
  const [resetPassStoreId, setResetPassStoreId] = useState(null);
  const [resetPassValue, setResetPassValue] = useState('');

  // --- PRECISE LOCATION SERVICES STATE ---
  const [customerLocation, setCustomerLocation] = useState({
    name: 'Swaroop Nagar, Kanpur',
    lat: 26.4784,
    lng: 80.3205,
    accuracyMeters: 14,
    isDeviceGps: false,
    loading: false,
    error: null
  });
  const [showLocationModal, setShowLocationModal] = useState(false);

  // Custom coordinate input fields for fine-tuning
  const [customLatInput, setCustomLatInput] = useState('26.4784');
  const [customLngInput, setCustomLngInput] = useState('80.3205');
  const [customLandmarkInput, setCustomLandmarkInput] = useState('B-14, Near Moti Jheel, Swaroop Nagar');

  // --- AUDIO ALERTS & SOUND STATE ---
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isAlarmPlaying, setIsAlarmPlaying] = useState(false);

  // --- CUSTOMER APP STATE ---
  const [selectedArea, setSelectedArea] = useState('All Kanpur');
  const [selectedStoreId, setSelectedStoreId] = useState('store_1');
  const [customerTab, setCustomerTab] = useState('shop'); // 'shop' | 'cart' | 'orders'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState({
    store_1: { p_101: 1, p_104: 2 }
  });
  const [deliveryAddress, setDeliveryAddress] = useState(
    'B-14, Near Moti Jheel, Swaroop Nagar, Kanpur [GPS: 26.4784, 80.3205]'
  );
  const [paymentMethod, setPaymentMethod] = useState('UPI Instant');
  const [showPwaBanner, setShowPwaBanner] = useState(true);

  // Quick-Commerce Enhancements State (Blinkit/Zepto parity)
  const [couponCodeInput, setCouponCodeInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [riderTip, setRiderTip] = useState(10);
  const [deliveryInstructions, setDeliveryInstructions] = useState('Ring doorbell');

  // --- SHOPKEEPER DASHBOARD STATE ---
  const [tenantStoreId, setTenantStoreId] = useState('store_1');
  const [merchantTab, setMerchantTab] = useState('orders'); // 'orders' | 'catalog' | 'settings'
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    category: 'Staples & Atta',
    price: '',
    mrp: '',
    unit: '1 kg Pack',
    stockQty: '25'
  });
  // Rider assignment & OTP verification per order
  const [selectedRiderByOrder, setSelectedRiderByOrder] = useState({});
  const [otpInputByOrder, setOtpInputByOrder] = useState({});

  // --- ADMIN PORTAL STATE ---
  const [showNewStoreModal, setShowNewStoreModal] = useState(false);
  const [newStoreForm, setNewStoreForm] = useState({
    name: '',
    owner: '',
    phone: '',
    loginId: '',
    password: '',
    area: 'Swaroop Nagar',
    pincode: '208002',
    category: 'Grocery & Daily Needs',
    plan: 'Pro Growth (₹1,499/mo)',
    lat: '26.4784',
    lng: '80.3205'
  });

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3400);
  };

  // --- AUTOMATED AUDITORY REPEATING ALARM FOR PENDING ORDERS ---
  const tenantPendingOrders = useMemo(() => {
    return orders.filter((o) => o.storeId === tenantStoreId && o.status === 'PENDING');
  }, [orders, tenantStoreId]);

  useEffect(() => {
    if (!soundEnabled || tenantPendingOrders.length === 0) {
      setIsAlarmPlaying(false);
      return;
    }
    setIsAlarmPlaying(true);
    playOrderChime();
    const interval = setInterval(() => {
      playOrderChime();
    }, 8000);
    return () => clearInterval(interval);
  }, [soundEnabled, tenantPendingOrders.length]);

  // --- AUTHENTICATION HANDLERS ---
  const handleMerchantLogin = (e) => {
    e.preventDefault();
    const targetStore = stores.find((s) => s.id === merchantLoginStoreId);
    if (!targetStore) return;
    if (!targetStore.isActive) {
      setMerchantAuthError('This store account has been suspended by Super-Admin.');
      return;
    }
    if (merchantPasswordInput === targetStore.password) {
      setAuthenticatedStoreId(targetStore.id);
      setTenantStoreId(targetStore.id);
      setMerchantAuthError('');
      setMerchantPasswordInput('');
      showToast(`Authenticated into ${targetStore.name} dashboard!`);
    } else {
      setMerchantAuthError('Incorrect store password! Unauthorized access blocked.');
    }
  };

  const handleMerchantLogout = () => {
    setAuthenticatedStoreId(null);
    setMerchantPasswordInput('');
    showToast('Logged out of Shopkeeper session safely.');
  };

  const handleChangeMerchantPassword = (e) => {
    e.preventDefault();
    if (!newMerchantPassInput || newMerchantPassInput.trim().length < 4) {
      showToast('Password must be at least 4 characters.', 'error');
      return;
    }
    setStores((prev) =>
      prev.map((s) =>
        s.id === currentTenantStore.id ? { ...s, password: newMerchantPassInput.trim() } : s
      )
    );
    setNewMerchantPassInput('');
    showToast(`Password updated for ${currentTenantStore.name}!`);
  };

  const handleAdminLogin = (e) => {
    e.preventDefault();
    if (adminPasswordInput === adminMasterPassword) {
      setIsAdminAuthenticated(true);
      setAdminAuthError('');
      setAdminPasswordInput('');
      showToast('Super-Admin Portal Unlocked!');
    } else {
      setAdminAuthError('Invalid Master Password! Access denied.');
    }
  };

  const handleChangeAdminPassword = (e) => {
    e.preventDefault();
    if (!newAdminPassInput || newAdminPassInput.trim().length < 5) {
      showToast('Master password must be at least 5 characters.', 'error');
      return;
    }
    setAdminMasterPassword(newAdminPassInput.trim());
    setNewAdminPassInput('');
    showToast('Super-Admin Master Password updated!');
  };

  const handleAdminResetStorePassword = (e) => {
    e.preventDefault();
    if (!resetPassStoreId || !resetPassValue.trim()) return;
    setStores((prev) =>
      prev.map((s) => (s.id === resetPassStoreId ? { ...s, password: resetPassValue.trim() } : s))
    );
    const st = stores.find((s) => s.id === resetPassStoreId);
    if (authenticatedStoreId === resetPassStoreId) {
      setAuthenticatedStoreId(null);
    }
    setResetPassStoreId(null);
    setResetPassValue('');
    showToast(`Reset password for ${st?.name} & revoked old sessions!`);
  };

  // --- PRECISE GPS GEOLOCATION HANDLER ---
  const requestDevicePreciseGps = () => {
    if (!navigator.geolocation) {
      showToast('Geolocation is not supported by your browser.', 'error');
      return;
    }
    setCustomerLocation((prev) => ({ ...prev, loading: true, error: null }));
    showToast('Detecting precise satellite/cellular GPS coordinates...');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        const accMeters = Math.round(accuracy || 10);
        setCustomerLocation({
          name: `Precise GPS (${latitude.toFixed(5)}, ${longitude.toFixed(5)})`,
          lat: latitude,
          lng: longitude,
          accuracyMeters: accMeters,
          isDeviceGps: true,
          loading: false,
          error: null
        });
        setCustomLatInput(latitude.toFixed(5));
        setCustomLngInput(longitude.toFixed(5));

        const updatedAddr = `Flat/House No. __, Near Landmark, GPS: [${latitude.toFixed(5)}, ${longitude.toFixed(5)}] (±${accMeters}m)`;
        setDeliveryAddress(updatedAddr);
        showToast(`Precise GPS locked! ±${accMeters}m accuracy (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`);
        setShowLocationModal(false);
      },
      (err) => {
        console.warn('Geolocation error:', err.message);
        setCustomerLocation((prev) => ({
          ...prev,
          loading: false,
          error: 'GPS access denied or unavailable in sandbox iframe. Tap below to use Kanpur coordinates.'
        }));
        showToast('GPS access denied. You can enter exact coordinates manually.', 'error');
      },
      { timeout: 12000, enableHighAccuracy: true, maximumAge: 0 }
    );
  };

  const handleApplyCustomPreciseLocation = (e) => {
    e.preventDefault();
    const latNum = parseFloat(customLatInput) || 26.4784;
    const lngNum = parseFloat(customLngInput) || 80.3205;
    const landmark = customLandmarkInput.trim() || 'Custom Precise Drop-off Point';

    setCustomerLocation({
      name: `${landmark} (${latNum.toFixed(4)}, ${lngNum.toFixed(4)})`,
      lat: latNum,
      lng: lngNum,
      accuracyMeters: 5,
      isDeviceGps: true,
      loading: false,
      error: null
    });
    setDeliveryAddress(`${landmark} [GPS: ${latNum.toFixed(5)}, ${lngNum.toFixed(5)}]`);
    setShowLocationModal(false);
    showToast(`Precise location applied to order drop-off!`);
  };

  const setPresetLocation = (preset) => {
    setCustomerLocation({
      name: preset.label,
      lat: preset.lat,
      lng: preset.lng,
      accuracyMeters: 15,
      isDeviceGps: false,
      loading: false,
      error: null
    });
    setCustomLatInput(preset.lat.toString());
    setCustomLngInput(preset.lng.toString());
    setCustomLandmarkInput(preset.label);
    setDeliveryAddress(`${preset.label}, Kanpur [GPS: ${preset.lat}, ${preset.lng}]`);
    setShowLocationModal(false);
    showToast(`Location set to ${preset.label}`);
  };

  // --- DERIVED DATA ---
  const currentCustomerStore = useMemo(
    () => stores.find((s) => s.id === selectedStoreId) || stores[0],
    [stores, selectedStoreId]
  );

  const currentTenantStore = useMemo(
    () => stores.find((s) => s.id === tenantStoreId) || stores[0],
    [stores, tenantStoreId]
  );

  const storesWithDistance = useMemo(() => {
    return stores.map((s) => {
      const dist = calculateDistanceKm(customerLocation.lat, customerLocation.lng, s.lat, s.lng);
      const isWithinRadius = dist <= s.radiusKm;
      return { ...s, distanceKm: dist, isWithinRadius };
    });
  }, [stores, customerLocation]);

  const currentStoreCalculated = useMemo(() => {
    return (
      storesWithDistance.find((s) => s.id === currentCustomerStore.id) || {
        ...currentCustomerStore,
        distanceKm: 0,
        isWithinRadius: true
      }
    );
  }, [storesWithDistance, currentCustomerStore]);

  const customerStoreProducts = useMemo(() => {
    return products.filter((p) => {
      if (p.storeId !== currentCustomerStore.id || !p.visible) return false;
      if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
      if (searchQuery.trim() && !p.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    });
  }, [products, currentCustomerStore, selectedCategory, searchQuery]);

  const customerCategories = useMemo(() => {
    const cats = new Set(
      products.filter((p) => p.storeId === currentCustomerStore.id && p.visible).map((p) => p.category)
    );
    return ['All', ...Array.from(cats)];
  }, [products, currentCustomerStore]);

  const activeStoreCart = cart[currentCustomerStore.id] || {};

  const cartItemsList = useMemo(() => {
    return Object.entries(activeStoreCart)
      .map(([pid, qty]) => {
        const prod = products.find((p) => p.id === pid);
        return prod && qty > 0 ? { ...prod, qty } : null;
      })
      .filter(Boolean);
  }, [activeStoreCart, products]);

  const cartSubtotal = useMemo(
    () => cartItemsList.reduce((acc, item) => acc + item.price * item.qty, 0),
    [cartItemsList]
  );

  const cartMrpTotal = useMemo(
    () => cartItemsList.reduce((acc, item) => acc + (item.mrp || item.price) * item.qty, 0),
    [cartItemsList]
  );

  const freeDeliveryThreshold = currentCustomerStore.freeDeliveryThreshold || 199;
  const isFreeDeliveryUnlocked = cartSubtotal >= freeDeliveryThreshold || appliedCoupon?.code === 'FREEDEL';
  const deliveryFee = isFreeDeliveryUnlocked ? 0 : 15;
  const handlingFee = cartSubtotal > 0 ? 5 : 0;
  const smallCartFee = cartSubtotal > 0 && cartSubtotal < currentCustomerStore.minOrder ? 15 : 0;
  const couponDiscount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (cartSubtotal < appliedCoupon.minSubtotal) return 0;
    if (appliedCoupon.code === 'FREEDEL') return 0; // Handled via deliveryFee
    return appliedCoupon.discount;
  }, [appliedCoupon, cartSubtotal]);

  const grandTotal = Math.max(0, cartSubtotal + deliveryFee + handlingFee + smallCartFee + riderTip - couponDiscount);
  const totalSavings = (cartMrpTotal - cartSubtotal) + couponDiscount + (isFreeDeliveryUnlocked ? 15 : 0);

  // --- HANDLERS: CUSTOMER ---
  const updateCartQty = (storeId, productId, delta) => {
    setCart((prev) => {
      const storeCart = { ...(prev[storeId] || {}) };
      const nextQty = (storeCart[productId] || 0) + delta;
      const prod = products.find((p) => p.id === productId);
      if (prod && nextQty > prod.stockQty && delta > 0) {
        showToast(`Only ${prod.stockQty} units available in stock!`, 'error');
        return prev;
      }
      if (nextQty <= 0) {
        delete storeCart[productId];
      } else {
        storeCart[productId] = nextQty;
      }
      return { ...prev, [storeId]: storeCart };
    });
  };

  const handleApplyCoupon = (codeStr) => {
    const clean = (codeStr || couponCodeInput).trim().toUpperCase();
    const found = PROMO_COUPONS.find((c) => c.code === clean);
    if (!found) {
      showToast('Invalid promo code. Try KANPUR30 or FIRST50', 'error');
      return;
    }
    if (cartSubtotal < found.minSubtotal) {
      showToast(`Add ₹${found.minSubtotal - cartSubtotal} more to use ${found.code}`, 'error');
      return;
    }
    setAppliedCoupon(found);
    setCouponCodeInput(found.code);
    showToast(`Coupon ${found.code} applied! (${found.desc})`);
  };

  const handlePlaceOrder = () => {
    if (!currentCustomerStore.isOpen || !currentCustomerStore.isActive) {
      showToast('This store is currently closed for instant deliveries.', 'error');
      return;
    }
    if (!currentStoreCalculated.isWithinRadius) {
      showToast(
        `You are ${currentStoreCalculated.distanceKm} km away. Outside ${currentCustomerStore.name}'s ${currentCustomerStore.radiusKm} km delivery radius!`,
        'error'
      );
      return;
    }
    if (cartItemsList.length === 0) {
      showToast('Your cart is empty!', 'error');
      return;
    }

    const generatedOtp = String(Math.floor(1000 + Math.random() * 9000));
    const newOrd = {
      id: `ORD-${Math.floor(8825 + Math.random() * 900)}`,
      storeId: currentCustomerStore.id,
      customerName: 'Harsh (You)',
      customerPhone: '+91 98390 55555',
      address: deliveryAddress,
      items: cartItemsList.map((i) => ({
        productId: i.id,
        name: i.name,
        qty: i.qty,
        price: i.price
      })),
      total: grandTotal,
      discount: couponDiscount,
      deliveryFee,
      handlingFee,
      riderTip,
      deliveryInstructions,
      deliveryOtp: generatedOtp,
      rider: null,
      status: 'PENDING',
      createdAt: 'Just now',
      paymentMode: paymentMethod
    };

    // Automatically decrement stock quantities in real time
    setProducts((prev) =>
      prev.map((prod) => {
        const orderedQty = activeStoreCart[prod.id] || 0;
        if (orderedQty > 0 && prod.storeId === currentCustomerStore.id) {
          const nextStock = Math.max(0, prod.stockQty - orderedQty);
          return { ...prod, stockQty: nextStock, inStock: nextStock > 0 };
        }
        return prod;
      })
    );

    setOrders((prev) => [newOrd, ...prev]);
    setCart((prev) => ({ ...prev, [currentCustomerStore.id]: {} }));
    setAppliedCoupon(null);
    setCouponCodeInput('');
    setCustomerTab('orders');

    playOrderChime();
    showToast(`Order ${newOrd.id} placed! Share OTP ${generatedOtp} at delivery.`);
  };

  // --- HANDLERS: SHOPKEEPER ---
  const handleToggleStoreOpen = (storeId) => {
    setStores((prev) =>
      prev.map((s) => {
        if (s.id === storeId) {
          const nextState = !s.isOpen;
          showToast(`${s.name} is now ${nextState ? 'OPEN' : 'CLOSED'} for instant delivery.`);
          return { ...s, isOpen: nextState };
        }
        return s;
      })
    );
  };

  const handleUpdateOrderStatus = (orderId, nextStatus) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return;

    // If dispatching, attach selected delivery partner
    if (nextStatus === 'DISPATCHED') {
      const riderId = selectedRiderByOrder[orderId] || INITIAL_RIDERS[0].id;
      const riderObj = INITIAL_RIDERS.find((r) => r.id === riderId) || INITIAL_RIDERS[0];
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status: nextStatus, rider: riderObj } : o))
      );
      showToast(`Order ${orderId} dispatched with ${riderObj.name}!`);
      return;
    }

    // If completing delivery, verify 4-digit customer OTP if typed (or allow instant verify)
    if (nextStatus === 'DELIVERED') {
      const enteredOtp = (otpInputByOrder[orderId] || '').trim();
      if (enteredOtp && enteredOtp !== targetOrder.deliveryOtp) {
        showToast(`Incorrect Customer Delivery PIN! Expected: ${targetOrder.deliveryOtp}`, 'error');
        return;
      }
    }

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: nextStatus } : o))
    );
    showToast(`Order ${orderId} updated to ${nextStatus}`);
  };

  const handleToggleProductStock = (productId) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === productId
          ? { ...p, inStock: !p.inStock, stockQty: !p.inStock ? Math.max(10, p.stockQty) : 0 }
          : p
      )
    );
    showToast('Inventory status updated.');
  };

  const handleUpdateProductStockQty = (productId, delta) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const nextQty = Math.max(0, (p.stockQty || 0) + delta);
          return { ...p, stockQty: nextQty, inStock: nextQty > 0 };
        }
        return p;
      })
    );
  };

  const handleToggleProductVisibility = (productId) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, visible: !p.visible } : p))
    );
    showToast('Catalog visibility toggled.');
  };

  const handleDeleteProduct = (productId) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    showToast('Product removed from tenant catalog.', 'error');
  };

  const handleCreateProduct = (e) => {
    e.preventDefault();
    if (!newProduct.name.trim() || !newProduct.price) return;
    const priceNum = Number(newProduct.price) || 99;
    const mrpNum = Number(newProduct.mrp) || priceNum + 15;
    const created = {
      id: `p_${Date.now()}`,
      storeId: currentTenantStore.id,
      name: newProduct.name.trim(),
      category: newProduct.category,
      price: priceNum,
      mrp: mrpNum,
      unit: newProduct.unit || '1 Pack',
      inStock: true,
      visible: true,
      stockQty: Number(newProduct.stockQty) || 20
    };
    setProducts((prev) => [created, ...prev]);
    setNewProduct({ name: '', category: 'Staples & Atta', price: '', mrp: '', unit: '1 kg Pack', stockQty: '25' });
    setShowAddModal(false);
    showToast(`Added "${created.name}" to ${currentTenantStore.name}`);
  };

  const handleUpdateRadius = (storeId, delta) => {
    setStores((prev) =>
      prev.map((s) =>
        s.id === storeId
          ? { ...s, radiusKm: Math.max(1, Math.min(15, Number((s.radiusKm + delta).toFixed(1)))) }
          : s
      )
    );
  };

  // --- HANDLERS: SUPER ADMIN ---
  const handleToggleStoreActive = (storeId) => {
    setStores((prev) =>
      prev.map((s) => {
        if (s.id === storeId) {
          const next = !s.isActive;
          showToast(
            `${s.name} ${next ? 'reactivated on platform' : 'deactivated by Admin'}`,
            next ? 'success' : 'error'
          );
          if (!next && authenticatedStoreId === storeId) {
            setAuthenticatedStoreId(null);
          }
          return { ...s, isActive: next, isOpen: next ? s.isOpen : false };
        }
        return s;
      })
    );
  };

  const handleForceLogoutStore = (storeId) => {
    setStores((prev) =>
      prev.map((s) => (s.id === storeId ? { ...s, activeSessions: 0 } : s))
    );
    if (authenticatedStoreId === storeId) {
      setAuthenticatedStoreId(null);
    }
    showToast('All active merchant sessions revoked & JWT tokens invalidated.');
  };

  const handleOnboardStore = (e) => {
    e.preventDefault();
    if (!newStoreForm.name.trim() || !newStoreForm.owner.trim()) return;
    const slug = newStoreForm.name.trim().toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8);
    const createdStore = {
      id: `store_${Date.now()}`,
      name: newStoreForm.name.trim(),
      owner: newStoreForm.owner.trim(),
      phone: newStoreForm.phone || '+91 98390 00000',
      loginId: newStoreForm.loginId.trim() || `${slug}@localmart.in`,
      password: newStoreForm.password.trim() || `${slug}123`,
      area: newStoreForm.area,
      pincode: newStoreForm.pincode,
      lat: Number(newStoreForm.lat) || 26.4784,
      lng: Number(newStoreForm.lng) || 80.3205,
      radiusKm: 3.0,
      isOpen: true,
      isActive: true,
      plan: newStoreForm.plan,
      billingStatus: 'Paid',
      rating: 4.7,
      deliveryEta: '15-20 mins',
      minOrder: 99,
      freeDeliveryThreshold: 199,
      category: newStoreForm.category,
      activeSessions: 1
    };
    setStores((prev) => [...prev, createdStore]);
    setShowNewStoreModal(false);
    setNewStoreForm({
      name: '',
      owner: '',
      phone: '',
      loginId: '',
      password: '',
      area: 'Swaroop Nagar',
      pincode: '208002',
      category: 'Grocery & Daily Needs',
      plan: 'Pro Growth (₹1,499/mo)',
      lat: '26.4784',
      lng: '80.3205'
    });
    showToast(`Onboarded ${createdStore.name} with dedicated password protection!`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* TOP PLATFORM BAR & ROLE SWITCHER */}
      <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur border-b border-slate-800 px-4 py-3">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-white">LocalMart</h1>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Quick-Commerce SaaS
                </span>
                {tenantPendingOrders.length > 0 && (
                  <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                    <Bell className="w-3 h-3 text-rose-400 animate-bounce" />
                    <span>{tenantPendingOrders.length} New Order Alert</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Multi-Store Instant Delivery • Password-Isolated Tenants • Live GPS & OTP
              </p>
            </div>
          </div>

          {/* 3-IN-1 ARCHITECTURE ROLE SWITCHER */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveSurface('customer')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeSurface === 'customer'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>1. Customer App</span>
            </button>
            <button
              onClick={() => setActiveSurface('shopkeeper')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeSurface === 'shopkeeper'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>2. Shopkeeper Web</span>
              {authenticatedStoreId ? (
                <UserCheck className="w-3 h-3 text-emerald-300" />
              ) : (
                <Lock className="w-3 h-3 text-amber-400" />
              )}
            </button>
            <button
              onClick={() => setActiveSurface('admin')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeSurface === 'admin'
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>3. Admin Portal</span>
              {isAdminAuthenticated ? (
                <UserCheck className="w-3 h-3 text-emerald-200" />
              ) : (
                <Lock className="w-3 h-3 text-amber-400" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* PWA WEB DEPLOYMENT BANNER */}
      {showPwaBanner && (
        <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/60 border-b border-slate-800 px-4 py-2 text-xs">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-slate-300">
              <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong className="text-white">Web PWA Method Active:</strong> Install via Chrome menu &gt; <em>"Add to Home Screen"</em>. Each store & admin portal is strictly protected by individual passwords.
              </span>
            </div>
            <button
              onClick={() => setShowPwaBanner(false)}
              className="text-slate-400 hover:text-slate-200 text-[11px]"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-2xl border text-xs font-medium bg-slate-900 border-emerald-500/40 text-emerald-300">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toast.msg}</span>
        </div>
      )}

      {/* PRECISE LOCATION SELECTOR MODAL */}
      {showLocationModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">Customer Precise Location</h3>
              </div>
              <button
                onClick={() => setShowLocationModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Set your exact delivery pin. The app calculates your straight-line distance to nearby stores using the Haversine formula to guarantee instant delivery eligibility.
            </p>

            <button
              onClick={requestDevicePreciseGps}
              className="w-full py-3 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition"
            >
              <Crosshair className="w-4 h-4 text-emerald-200" />
              <span>{customerLocation.loading ? 'Pinpointing GPS Satellite...' : 'Use My Precise Current Location'}</span>
            </button>

            {customerLocation.error && (
              <p className="text-[11px] text-amber-400 bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20">
                {customerLocation.error}
              </p>
            )}

            <form onSubmit={handleApplyCustomPreciseLocation} className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block">
                Manual Fine-Tuning (House / Landmark / GPS)
              </span>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">House/Flat No. & Landmark</label>
                <input
                  type="text"
                  required
                  value={customLandmarkInput}
                  onChange={(e) => setCustomLandmarkInput(e.target.value)}
                  placeholder="e.g., Flat 302, Emerald Court, Near Moti Jheel"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Exact Latitude</label>
                  <input
                    type="text"
                    required
                    value={customLatInput}
                    onChange={(e) => setCustomLatInput(e.target.value)}
                    placeholder="26.4784"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Exact Longitude</label>
                  <input
                    type="text"
                    required
                    value={customLngInput}
                    onChange={(e) => setCustomLngInput(e.target.value)}
                    placeholder="80.3205"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold border border-slate-700 transition"
              >
                Apply Custom Precise Location
              </button>
            </form>

            <div className="pt-2 border-t border-slate-800">
              <span className="text-[11px] uppercase tracking-wider font-semibold text-slate-400 block mb-2">
                Or Quick-Select Kanpur Neighborhood Coordinates:
              </span>
              <div className="space-y-1.5">
                {KANPUR_GPS_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setPresetLocation(preset)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs flex items-center justify-between transition"
                  >
                    <div>
                      <span className="font-semibold text-white block">{preset.label}</span>
                      <span className="text-[10px] text-slate-400">
                        Lat: {preset.lat}, Lng: {preset.lng}
                      </span>
                    </div>
                    <span className="text-emerald-400 font-bold text-xs">Select &gt;</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MAIN WORKSPACE */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {/* =========================================================
            SURFACE 1: CUSTOMER APP (BLINKIT / ZEPTO QUICK-COMMERCE GRADE)
           ========================================================= */}
        {activeSurface === 'customer' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Store Selector & Architecture Context */}
            <div className="lg:col-span-5 space-y-4">
              {/* Customer Precise Location Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                      <Target className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div className="truncate">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] uppercase font-bold text-emerald-400">
                          {customerLocation.isDeviceGps ? 'Precise Satellite GPS' : 'Current Locality'}
                        </span>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        <span className="text-[10px] text-slate-400">
                          (±{customerLocation.accuracyMeters}m)
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-white truncate">
                        {customerLocation.name}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowLocationModal(true)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold shrink-0 transition"
                  >
                    Change Pin
                  </button>
                </div>

                <button
                  onClick={requestDevicePreciseGps}
                  className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 transition"
                >
                  <Crosshair className="w-4 h-4 text-emerald-400" />
                  <span>
                    {customerLocation.loading ? 'Pinpointing GPS...' : 'Use My Current Precise Location'}
                  </span>
                </button>
              </div>

              {/* Hyperlocal Store Directory */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                    Hyperlocal Radius Matching
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" /> Kanpur Cluster
                  </span>
                </div>
                <h2 className="text-base font-bold text-white mb-1">
                  Nearby Kanpur Storefronts
                </h2>
                <p className="text-xs text-slate-400 mb-4">
                  Distances measured from your exact pin <strong>({customerLocation.lat.toFixed(4)}, {customerLocation.lng.toFixed(4)})</strong>.
                </p>

                {/* Area Filter Pills */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {['All Kanpur', 'Swaroop Nagar', 'Kakadeo', 'Kidwai Nagar'].map((area) => (
                    <button
                      key={area}
                      onClick={() => setSelectedArea(area)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                        selectedArea === area
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {area}
                    </button>
                  ))}
                </div>

                {/* Store Cards with Live Haversine Distance */}
                <div className="space-y-2.5">
                  {storesWithDistance
                    .filter((s) => s.isActive && (selectedArea === 'All Kanpur' || s.area === selectedArea))
                    .map((store) => {
                      const isSelected = store.id === currentCustomerStore.id;
                      return (
                        <div
                          key={store.id}
                          onClick={() => {
                            setSelectedStoreId(store.id);
                            setSelectedCategory('All');
                          }}
                          className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-emerald-950/30 border-emerald-500/60 shadow-md'
                              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="text-sm font-semibold text-white">{store.name}</h3>
                                <span
                                  className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                                    store.isOpen
                                      ? 'bg-emerald-500/20 text-emerald-300'
                                      : 'bg-rose-500/20 text-rose-300'
                                  }`}
                                >
                                  {store.isOpen ? 'OPEN' : 'CLOSED'}
                                </span>
                              </div>
                              <p className="text-xs text-slate-400 mt-0.5">
                                {store.category} • {store.area} ({store.pincode})
                              </p>
                            </div>
                            <span className="text-xs font-semibold text-emerald-400 bg-emerald-950 px-2 py-1 rounded-lg border border-emerald-800/50">
                              ⚡ {store.deliveryEta}
                            </span>
                          </div>

                          <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800/80 text-[11px]">
                            <div className="flex items-center gap-1.5">
                              <Compass className="w-3.5 h-3.5 text-slate-400" />
                              <span className="font-semibold text-slate-200">{store.distanceKm} km away</span>
                              <span className="text-slate-500">(Free del &gt; ₹{store.freeDeliveryThreshold || 199})</span>
                            </div>

                            <span
                              className={`font-semibold px-2 py-0.5 rounded text-[10px] ${
                                store.isWithinRadius
                                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                              }`}
                            >
                              {store.isWithinRadius ? '✓ In Delivery Zone' : '✗ Out of Radius'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>

            {/* Right Column: Interactive Mobile Web PWA Frame */}
            <div className="lg:col-span-7 flex justify-center">
              <div className="w-full max-w-md bg-slate-900 border-4 border-slate-800 rounded-[32px] overflow-hidden shadow-2xl flex flex-col min-h-[690px]">
                {/* Mobile Browser URL / PWA Header Bar */}
                <div className="bg-slate-950 px-4 py-2 flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800">
                  <div className="flex items-center gap-1.5 text-slate-300 font-mono text-[10px] truncate">
                    <Lock className="w-3 h-3 text-emerald-400" />
                    <span>localmart.in/{currentCustomerStore.area.toLowerCase().replace(/\s+/g, '-')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-slate-800 rounded text-[10px] text-emerald-300 font-semibold">
                      ⚡ {currentCustomerStore.deliveryEta}
                    </span>
                  </div>
                </div>

                {/* App Storefront Header */}
                <div className="bg-gradient-to-r from-emerald-900/50 to-slate-900 p-4 border-b border-slate-800">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider font-semibold text-emerald-400">
                        Instant Storefront
                      </span>
                      <h3 className="text-base font-bold text-white">{currentCustomerStore.name}</h3>
                      <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-emerald-400" />
                        {currentCustomerStore.area} • {currentStoreCalculated.distanceKm} km away
                      </p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`inline-block text-[10px] font-bold px-2.5 py-1 rounded-full ${
                          currentCustomerStore.isOpen
                            ? 'bg-emerald-500 text-slate-950'
                            : 'bg-rose-500 text-white'
                        }`}
                      >
                        {currentCustomerStore.isOpen ? 'INSTANT DELIVERY ON' : 'STORE CLOSED'}
                      </span>
                    </div>
                  </div>

                  {/* Dynamic Free Delivery Progress Bar (Blinkit/Zepto Style) */}
                  {cartSubtotal > 0 && (
                    <div className="mt-3 bg-slate-950/90 p-2.5 rounded-xl border border-slate-800">
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        {isFreeDeliveryUnlocked ? (
                          <span className="text-emerald-400 font-bold flex items-center gap-1">
                            <Zap className="w-3.5 h-3.5" /> FREE Instant Delivery Unlocked!
                          </span>
                        ) : (
                          <span className="text-slate-300">
                            Add <strong className="text-emerald-400">₹{freeDeliveryThreshold - cartSubtotal}</strong> more for <strong>FREE Delivery</strong>
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400">
                          ₹{cartSubtotal} / ₹{freeDeliveryThreshold}
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                          style={{ width: `${Math.min(100, (cartSubtotal / freeDeliveryThreshold) * 100)}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Geofence Warning if Outside Radius */}
                  {!currentStoreCalculated.isWithinRadius && (
                    <div className="mt-2.5 p-2 rounded-lg bg-rose-500/20 border border-rose-500/40 text-[11px] text-rose-300 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>
                        You are {currentStoreCalculated.distanceKm} km away (outside store's {currentCustomerStore.radiusKm} km radius). Instant checkout disabled for this store.
                      </span>
                    </div>
                  )}
                </div>

                {/* Mobile Navigation Content */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                  {customerTab === 'shop' && (
                    <>
                      {/* Search Input */}
                      <div className="relative">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder={`Search products in ${currentCustomerStore.name}...`}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                        />
                      </div>

                      {/* Category Chips */}
                      <div className="flex gap-1.5 overflow-x-auto pb-1">
                        {customerCategories.map((cat) => (
                          <button
                            key={cat}
                            onClick={() => setSelectedCategory(cat)}
                            className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition ${
                              selectedCategory === cat
                                ? 'bg-emerald-500 text-slate-950 font-semibold'
                                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                            }`}
                          >
                            {cat}
                          </button>
                        ))}
                      </div>

                      {/* Product Grid with Savings % Badge & Live Stock Count */}
                      <div className="space-y-2.5">
                        {customerStoreProducts.length === 0 ? (
                          <div className="text-center py-10 text-xs text-slate-500">
                            No matching products in this store catalog.
                          </div>
                        ) : (
                          customerStoreProducts.map((prod) => {
                            const qtyInCart = activeStoreCart[prod.id] || 0;
                            const discountPct = prod.mrp > prod.price ? Math.round(((prod.mrp - prod.price) / prod.mrp) * 100) : 0;
                            return (
                              <div
                                key={prod.id}
                                className="bg-slate-950/90 border border-slate-800/90 rounded-xl p-3 flex items-center justify-between gap-3"
                              >
                                <div>
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    {discountPct > 0 && (
                                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                        {discountPct}% OFF
                                      </span>
                                    )}
                                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                                      {prod.category}
                                    </span>
                                    <span className="text-[11px] text-slate-400">{prod.unit}</span>
                                  </div>
                                  <h4 className="text-xs font-semibold text-white mt-1">{prod.name}</h4>
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-sm font-bold text-emerald-400">₹{prod.price}</span>
                                    <span className="text-[11px] text-slate-500 line-through">₹{prod.mrp}</span>
                                    {prod.inStock && prod.stockQty <= 10 && (
                                      <span className="text-[10px] text-amber-400 font-semibold">
                                        Only {prod.stockQty} left!
                                      </span>
                                    )}
                                  </div>
                                </div>

                                <div>
                                  {!prod.inStock || prod.stockQty <= 0 ? (
                                    <span className="text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-slate-800 text-rose-400 border border-rose-500/20">
                                      Out of Stock
                                    </span>
                                  ) : qtyInCart === 0 ? (
                                    <button
                                      onClick={() => updateCartQty(currentCustomerStore.id, prod.id, 1)}
                                      className="px-3.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition"
                                    >
                                      + ADD
                                    </button>
                                  ) : (
                                    <div className="flex items-center gap-2 bg-emerald-600 text-white px-2 py-1 rounded-xl">
                                      <button
                                        onClick={() => updateCartQty(currentCustomerStore.id, prod.id, -1)}
                                        className="p-0.5 hover:bg-emerald-700 rounded"
                                      >
                                        <Minus className="w-3.5 h-3.5" />
                                      </button>
                                      <span className="text-xs font-bold min-w-[16px] text-center">
                                        {qtyInCart}
                                      </span>
                                      <button
                                        onClick={() => updateCartQty(currentCustomerStore.id, prod.id, 1)}
                                        className="p-0.5 hover:bg-emerald-700 rounded"
                                      >
                                        <Plus className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>

                      {/* Sticky Floating View Cart Bar (Quick-Commerce Standard) */}
                      {cartItemsList.length > 0 && (
                        <div className="pt-2 sticky bottom-0">
                          <button
                            onClick={() => setCustomerTab('cart')}
                            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs shadow-xl flex items-center justify-between"
                          >
                            <span>
                              {cartItemsList.reduce((a, b) => a + b.qty, 0)} Items • ₹{cartSubtotal}
                            </span>
                            <span className="flex items-center gap-1">
                              Proceed to Checkout <ChevronRight className="w-4 h-4" />
                            </span>
                          </button>
                        </div>
                      )}
                    </>
                  )}

                  {customerTab === 'cart' && (
                    <div className="space-y-3.5">
                      <h4 className="text-sm font-bold text-white flex items-center justify-between">
                        <span>Instant Checkout Cart</span>
                        <span className="text-xs font-normal text-slate-400">{currentCustomerStore.name}</span>
                      </h4>

                      {cartItemsList.length === 0 ? (
                        <div className="text-center py-12 bg-slate-950 rounded-2xl border border-slate-800 p-6">
                          <ShoppingBag className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                          <p className="text-xs text-slate-400">Your cart for this store is empty.</p>
                          <button
                            onClick={() => setCustomerTab('shop')}
                            className="mt-3 px-4 py-1.5 bg-emerald-600 text-white rounded-xl text-xs font-semibold"
                          >
                            Browse Products
                          </button>
                        </div>
                      ) : (
                        <>
                          {/* Cart Items */}
                          <div className="space-y-2">
                            {cartItemsList.map((item) => (
                              <div
                                key={item.id}
                                className="flex items-center justify-between bg-slate-950 p-3 rounded-xl border border-slate-800"
                              >
                                <div>
                                  <p className="text-xs font-semibold text-white">{item.name}</p>
                                  <p className="text-[11px] text-slate-400">
                                    ₹{item.price} × {item.qty} = ₹{item.price * item.qty}
                                  </p>
                                </div>
                                <div className="flex items-center gap-2 bg-slate-800 px-2 py-1 rounded-lg">
                                  <button
                                    onClick={() => updateCartQty(currentCustomerStore.id, item.id, -1)}
                                    className="text-slate-300 hover:text-white"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="text-xs font-bold">{item.qty}</span>
                                  <button
                                    onClick={() => updateCartQty(currentCustomerStore.id, item.id, 1)}
                                    className="text-slate-300 hover:text-white"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Promo Coupon Engine (KANPUR30 / FIRST50 / FREEDEL) */}
                          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-bold uppercase text-emerald-400 flex items-center gap-1">
                                <Tag className="w-3.5 h-3.5" /> Apply Promo Coupon
                              </span>
                              {appliedCoupon && (
                                <button
                                  onClick={() => {
                                    setAppliedCoupon(null);
                                    setCouponCodeInput('');
                                  }}
                                  className="text-[10px] text-rose-400 hover:underline"
                                >
                                  Remove ({appliedCoupon.code})
                                </button>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                value={couponCodeInput}
                                onChange={(e) => setCouponCodeInput(e.target.value)}
                                placeholder="Enter KANPUR30 or FIRST50"
                                className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white uppercase font-mono"
                              />
                              <button
                                type="button"
                                onClick={() => handleApplyCoupon()}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                              >
                                Apply
                              </button>
                            </div>
                            <div className="flex gap-1.5 overflow-x-auto pt-1">
                              {PROMO_COUPONS.map((c) => (
                                <button
                                  key={c.code}
                                  type="button"
                                  onClick={() => handleApplyCoupon(c.code)}
                                  className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] text-emerald-300 font-mono whitespace-nowrap"
                                >
                                  {c.code} (-₹{c.discount})
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Delivery Instructions & Rider Tip (Quick-Commerce Standard) */}
                          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2.5">
                            <div>
                              <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1">
                                Delivery Instructions
                              </label>
                              <div className="flex flex-wrap gap-1.5">
                                {['Ring doorbell', 'Leave at guard desk', 'Do not ring bell', 'Call on arrival'].map(
                                  (inst) => (
                                    <button
                                      key={inst}
                                      type="button"
                                      onClick={() => setDeliveryInstructions(inst)}
                                      className={`px-2 py-1 rounded-lg text-[10px] font-medium border ${
                                        deliveryInstructions === inst
                                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                                          : 'bg-slate-900 border-slate-800 text-slate-400'
                                      }`}
                                    >
                                      {inst}
                                    </button>
                                  )
                                )}
                              </div>
                            </div>

                            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                              <span className="text-[11px] text-slate-300 font-medium">
                                Tip Delivery Partner (100% goes to rider)
                              </span>
                              <div className="flex gap-1">
                                {[0, 10, 20, 30].map((tipVal) => (
                                  <button
                                    key={tipVal}
                                    type="button"
                                    onClick={() => setRiderTip(tipVal)}
                                    className={`px-2 py-1 rounded-lg text-[10px] font-bold border ${
                                      riderTip === tipVal
                                        ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                                        : 'bg-slate-900 text-slate-400 border-slate-800'
                                    }`}
                                  >
                                    {tipVal === 0 ? 'None' : `₹${tipVal}`}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Delivery Address & GPS Coordinates Display */}
                          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2.5">
                            <div className="flex items-center justify-between">
                              <label className="block text-[11px] font-semibold uppercase text-slate-400">
                                Delivery Drop-off Point
                              </label>
                              <span className="text-[10px] text-emerald-400 font-mono">
                                Dist: {currentStoreCalculated.distanceKm} km
                              </span>
                            </div>

                            <input
                              type="text"
                              value={deliveryAddress}
                              onChange={(e) => setDeliveryAddress(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                            />

                            <button
                              type="button"
                              onClick={requestDevicePreciseGps}
                              className="w-full py-1.5 px-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold flex items-center justify-center gap-1.5 transition"
                            >
                              <Crosshair className="w-3.5 h-3.5 text-emerald-400" />
                              <span>{customerLocation.loading ? 'Updating...' : 'Use My Current Precise Location Here'}</span>
                            </button>

                            <div className="pt-1">
                              <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1.5">
                                Payment Method
                              </label>
                              <div className="grid grid-cols-2 gap-2">
                                {['UPI Instant', 'Cash on Delivery'].map((mode) => (
                                  <button
                                    key={mode}
                                    type="button"
                                    onClick={() => setPaymentMethod(mode)}
                                    className={`py-1.5 px-2 rounded-lg text-xs font-medium border ${
                                      paymentMethod === mode
                                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                                        : 'bg-slate-900 border-slate-800 text-slate-400'
                                    }`}
                                  >
                                    {mode}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Itemized Quick-Commerce Bill Breakdown */}
                          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-xs space-y-1.5">
                            <div className="flex justify-between text-slate-400">
                              <span>Item Total (MRP ₹{cartMrpTotal})</span>
                              <span className="text-slate-200">₹{cartSubtotal}</span>
                            </div>
                            <div className="flex justify-between text-slate-400">
                              <span>Instant Delivery Partner Fee</span>
                              <span>
                                {deliveryFee === 0 ? (
                                  <span className="text-emerald-400 font-bold">FREE</span>
                                ) : (
                                  `₹${deliveryFee}`
                                )}
                              </span>
                            </div>
                            <div className="flex justify-between text-slate-400">
                              <span>Packaging & Handling Charge</span>
                              <span>₹{handlingFee}</span>
                            </div>
                            {smallCartFee > 0 && (
                              <div className="flex justify-between text-amber-400">
                                <span>Small Cart Fee (Below ₹{currentCustomerStore.minOrder})</span>
                                <span>₹{smallCartFee}</span>
                              </div>
                            )}
                            {riderTip > 0 && (
                              <div className="flex justify-between text-slate-400">
                                <span>Delivery Partner Tip</span>
                                <span>₹{riderTip}</span>
                              </div>
                            )}
                            {couponDiscount > 0 && (
                              <div className="flex justify-between text-emerald-400 font-semibold">
                                <span>Promo Discount ({appliedCoupon?.code})</span>
                                <span>-₹{couponDiscount}</span>
                              </div>
                            )}
                            <div className="flex justify-between text-sm font-bold text-white pt-1.5 border-t border-slate-800">
                              <span>Grand Total To Pay</span>
                              <span className="text-emerald-400">₹{grandTotal}</span>
                            </div>
                            {totalSavings > 0 && (
                              <div className="mt-1 py-1 px-2 rounded bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-300 font-semibold text-center">
                                🎉 You are saving ₹{totalSavings} on this instant order!
                              </div>
                            )}
                          </div>

                          <button
                            onClick={handlePlaceOrder}
                            disabled={!currentStoreCalculated.isWithinRadius || !currentCustomerStore.isOpen}
                            className={`w-full py-3 rounded-xl font-bold text-xs shadow-lg transition ${
                              !currentStoreCalculated.isWithinRadius || !currentCustomerStore.isOpen
                                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                            }`}
                          >
                            {!currentStoreCalculated.isWithinRadius
                              ? `Outside Delivery Radius (${currentStoreCalculated.distanceKm} km)`
                              : !currentCustomerStore.isOpen
                              ? 'Store Currently Closed'
                              : `Place Instant Order • ₹${grandTotal}`}
                          </button>
                        </>
                      )}
                    </div>
                  )}

                  {customerTab === 'orders' && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-bold text-white">Live 5-Stage Order Tracking</h4>
                      {orders.map((ord) => {
                        const st = stores.find((s) => s.id === ord.storeId);
                        const stageIdx = ORDER_STAGES.indexOf(ord.status);
                        return (
                          <div
                            key={ord.id}
                            className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2.5"
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-emerald-400">{ord.id}</span>
                              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                                {ord.status}
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <p className="text-xs font-semibold text-white">{st?.name}</p>
                              {ord.deliveryOtp && ord.status !== 'DELIVERED' && ord.status !== 'CANCELLED' && (
                                <span className="text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
                                  Delivery PIN: {ord.deliveryOtp}
                                </span>
                              )}
                            </div>

                            {/* 5-Stage Progress Stepper */}
                            {ord.status !== 'CANCELLED' && (
                              <div className="grid grid-cols-5 gap-1 pt-1">
                                {ORDER_STAGES.map((stg, i) => (
                                  <div key={stg} className="text-center">
                                    <div
                                      className={`h-1.5 rounded-full ${
                                        i <= stageIdx ? 'bg-emerald-500' : 'bg-slate-800'
                                      }`}
                                    />
                                    <span className="text-[8px] text-slate-400 block mt-1">{stg}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Assigned Rider Card */}
                            {ord.rider && (
                              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-[11px]">
                                <div>
                                  <span className="text-emerald-400 font-semibold block">
                                    🚴 Rider: {ord.rider.name}
                                  </span>
                                  <span className="text-[10px] text-slate-400">{ord.rider.vehicle}</span>
                                </div>
                                <span className="text-[10px] font-mono text-slate-300">{ord.rider.phone}</span>
                              </div>
                            )}

                            <div className="text-[11px] text-slate-400 space-y-0.5">
                              {ord.items.map((it, idx) => (
                                <div key={idx}>
                                  • {it.qty}x {it.name} (₹{it.price * it.qty})
                                </div>
                              ))}
                            </div>
                            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                              <span>{ord.paymentMode}</span>
                              <span className="font-bold text-white">Total: ₹{ord.total}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Bottom App Navigation Bar */}
                <div className="bg-slate-950 border-t border-slate-800 grid grid-cols-3 py-2 px-3">
                  <button
                    onClick={() => setCustomerTab('shop')}
                    className={`flex flex-col items-center gap-1 py-1 rounded-lg text-[11px] font-medium ${
                      customerTab === 'shop' ? 'text-emerald-400' : 'text-slate-400'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>Storefront</span>
                  </button>
                  <button
                    onClick={() => setCustomerTab('cart')}
                    className={`flex flex-col items-center gap-1 py-1 rounded-lg text-[11px] font-medium relative ${
                      customerTab === 'cart' ? 'text-emerald-400' : 'text-slate-400'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Cart ({cartItemsList.length})</span>
                  </button>
                  <button
                    onClick={() => setCustomerTab('orders')}
                    className={`flex flex-col items-center gap-1 py-1 rounded-lg text-[11px] font-medium ${
                      customerTab === 'orders' ? 'text-emerald-400' : 'text-slate-400'
                    }`}
                  >
                    <Truck className="w-4 h-4" />
                    <span>Orders ({orders.length})</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            SURFACE 2: SHOPKEEPER WEB DASHBOARD (PASSWORD PROTECTED PER STORE)
           ========================================================= */}
        {activeSurface === 'shopkeeper' && (
          <div className="space-y-6">
            {!authenticatedStoreId ? (
              /* SHOPKEEPER PASSWORD LOGIN GATE */
              <div className="max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5 my-6">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center">
                    <KeyRound className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                      Isolated Tenant Security
                    </span>
                    <h2 className="text-base font-bold text-white">Shopkeeper Partner Login</h2>
                    <p className="text-xs text-slate-400">
                      Each store is locked with its own password so no merchant can access another store's account.
                    </p>
                  </div>
                </div>

                <form onSubmit={handleMerchantLogin} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Select Your Storefront</label>
                    <select
                      value={merchantLoginStoreId}
                      onChange={(e) => {
                        setMerchantLoginStoreId(e.target.value);
                        setMerchantAuthError('');
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-semibold focus:outline-none focus:border-indigo-500"
                    >
                      {stores.map((st) => (
                        <option key={st.id} value={st.id}>
                          {st.name} ({st.area}) — {st.loginId}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Store Password</label>
                    <input
                      type="password"
                      required
                      value={merchantPasswordInput}
                      onChange={(e) => setMerchantPasswordInput(e.target.value)}
                      placeholder="Enter your private store password"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {merchantAuthError && (
                    <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>{merchantAuthError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition"
                  >
                    Unlock Store Dashboard
                  </button>
                </form>

                {/* Demo Credentials Helper Card for Testing */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-[11px]">
                  <span className="font-bold text-slate-300 block">
                    🔑 Demo Store Passwords (Click to Auto-Fill & Test):
                  </span>
                  <div className="space-y-1">
                    {stores.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => {
                          setMerchantLoginStoreId(st.id);
                          setMerchantPasswordInput(st.password);
                          setMerchantAuthError('');
                        }}
                        className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-900 cursor-pointer border border-transparent hover:border-slate-800"
                      >
                        <span className="text-slate-300 font-medium">{st.name}</span>
                        <span className="font-mono text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded">
                          Pass: {st.password}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* UNLOCKED SHOPKEEPER DASHBOARD */
              <>
                {/* AUDIBLE ALARM BANNER */}
                {tenantPendingOrders.length > 0 && (
                  <div className="bg-gradient-to-r from-rose-900/80 via-red-950 to-slate-900 border-2 border-rose-500 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-xl shadow-rose-950/40 animate-pulse">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-600 flex items-center justify-center text-white animate-bounce">
                        <Bell className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <span>Incoming Order Alert ({tenantPendingOrders.length} Pending)</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500 text-white font-mono">
                            RINGING
                          </span>
                        </h3>
                        <p className="text-xs text-rose-200">
                          Audio alert chiming to get shopkeeper's attention at the physical counter.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => playOrderChime()}
                        className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center gap-1.5 border border-slate-700"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-rose-400" />
                        <span>Test Audio Alarm</span>
                      </button>
                      <button
                        onClick={() => setSoundEnabled(!soundEnabled)}
                        className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5"
                      >
                        {soundEnabled ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5" />
                            <span>Mute Alarm</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Unmute Alarm</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {/* Authenticated Tenant Header */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center">
                      <Store className="w-5 h-5 text-indigo-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-400 flex items-center gap-1">
                          <Lock className="w-3 h-3" /> Password Authenticated
                        </span>
                        <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                          {currentTenantStore.loginId}
                        </span>
                      </div>
                      <h2 className="text-lg font-bold text-white">{currentTenantStore.name}</h2>
                      <p className="text-xs text-slate-400">
                        Owner: {currentTenantStore.owner} • GPS: ({currentTenantStore.lat}, {currentTenantStore.lng})
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      onClick={() => {
                        const next = !soundEnabled;
                        setSoundEnabled(next);
                        if (next) playOrderChime();
                        showToast(next ? 'Sound Alerts Enabled (Chime Tested)' : 'Sound Alerts Muted');
                      }}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition ${
                        soundEnabled
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
                      <span>{soundEnabled ? 'Counter Bell: ON' : 'Counter Bell: MUTED'}</span>
                    </button>

                    <button
                      onClick={() => handleToggleStoreOpen(currentTenantStore.id)}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold border transition ${
                        currentTenantStore.isOpen
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                          : 'bg-rose-500/15 border-rose-500/40 text-rose-300'
                      }`}
                    >
                      {currentTenantStore.isOpen ? (
                        <>
                          <ToggleRight className="w-4 h-4 text-emerald-400" />
                          <span>Store OPEN for Orders</span>
                        </>
                      ) : (
                        <>
                          <ToggleLeft className="w-4 h-4 text-rose-400" />
                          <span>Store CLOSED</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleMerchantLogout}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-200 hover:text-rose-300 border border-slate-700 text-xs font-semibold transition"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Lock / Switch Store</span>
                    </button>
                  </div>
                </div>

                {/* Sub-navigation Tabs */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div className="flex gap-2">
                    {[
                      { id: 'orders', label: 'Live Order Desk', icon: Truck },
                      { id: 'catalog', label: 'Product & Stock Catalog', icon: Package },
                      { id: 'settings', label: 'Radius & Password Security', icon: KeyRound }
                    ].map((t) => {
                      const Icon = t.icon;
                      return (
                        <button
                          key={t.id}
                          onClick={() => setMerchantTab(t.id)}
                          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition ${
                            merchantTab === t.id
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-900 text-slate-400 hover:text-white'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                          <span>{t.label}</span>
                          {t.id === 'orders' && tenantPendingOrders.length > 0 && (
                            <span className="px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[10px]">
                              {tenantPendingOrders.length}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {merchantTab === 'catalog' && (
                    <button
                      onClick={() => setShowAddModal(true)}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New Product</span>
                    </button>
                  )}
                </div>

                {/* TAB 1: LIVE ORDER DESK WITH RIDER ASSIGNMENT & OTP VERIFICATION */}
                {merchantTab === 'orders' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {orders
                      .filter((o) => o.storeId === currentTenantStore.id)
                      .map((ord) => (
                        <div
                          key={ord.id}
                          className={`bg-slate-900 border rounded-2xl p-5 flex flex-col justify-between gap-4 transition ${
                            ord.status === 'PENDING'
                              ? 'border-rose-500/70 shadow-lg shadow-rose-950/20'
                              : 'border-slate-800'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-bold text-indigo-400">{ord.id}</span>
                              <span
                                className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                                  ord.status === 'PENDING'
                                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                                    : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                                }`}
                              >
                                {ord.status}
                              </span>
                            </div>
                            <h3 className="text-sm font-semibold text-white">{ord.customerName}</h3>
                            <p className="text-xs text-slate-400 mt-0.5">{ord.address}</p>
                            {ord.deliveryInstructions && (
                              <p className="text-[11px] text-amber-300 mt-1">
                                📝 Note: {ord.deliveryInstructions}
                              </p>
                            )}
                            <div className="mt-3 pt-3 border-t border-slate-800 space-y-1">
                              {ord.items.map((it, i) => (
                                <div key={i} className="flex justify-between text-xs text-slate-300">
                                  <span>
                                    {it.qty} × {it.name}
                                  </span>
                                  <span className="font-medium">₹{it.price * it.qty}</span>
                                </div>
                              ))}
                            </div>

                            {/* Rider Assignment Selector when order is ACCEPTED or PACKING */}
                            {(ord.status === 'ACCEPTED' || ord.status === 'PACKING') && (
                              <div className="mt-3 pt-3 border-t border-slate-800">
                                <label className="block text-[11px] text-slate-400 mb-1">
                                  Assign Local Delivery Partner:
                                </label>
                                <select
                                  value={selectedRiderByOrder[ord.id] || INITIAL_RIDERS[0].id}
                                  onChange={(e) =>
                                    setSelectedRiderByOrder({
                                      ...selectedRiderByOrder,
                                      [ord.id]: e.target.value
                                    })
                                  }
                                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                                >
                                  {INITIAL_RIDERS.map((r) => (
                                    <option key={r.id} value={r.id}>
                                      {r.name} — {r.vehicle}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            )}

                            {/* OTP Handover Verification when DISPATCHED */}
                            {ord.status === 'DISPATCHED' && (
                              <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                                <input
                                  type="text"
                                  value={otpInputByOrder[ord.id] || ''}
                                  onChange={(e) =>
                                    setOtpInputByOrder({ ...otpInputByOrder, [ord.id]: e.target.value })
                                  }
                                  placeholder={`Enter 4-digit PIN (${ord.deliveryOtp})`}
                                  className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                                />
                              </div>
                            )}
                          </div>

                          <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                            <div>
                              <span className="text-[11px] text-slate-400 block">{ord.paymentMode}</span>
                              <span className="text-sm font-bold text-emerald-400">Total: ₹{ord.total}</span>
                            </div>

                            <div className="flex gap-2">
                              {ord.status === 'PENDING' && (
                                <>
                                  <button
                                    onClick={() => handleUpdateOrderStatus(ord.id, 'ACCEPTED')}
                                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow"
                                  >
                                    Accept Order (Stop Alarm)
                                  </button>
                                  <button
                                    onClick={() => handleUpdateOrderStatus(ord.id, 'CANCELLED')}
                                    className="px-3 py-2 rounded-xl bg-rose-600/20 text-rose-300 border border-rose-500/30 text-xs font-semibold"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                              {ord.status === 'ACCEPTED' && (
                                <button
                                  onClick={() => handleUpdateOrderStatus(ord.id, 'PACKING')}
                                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold"
                                >
                                  Start Packing
                                </button>
                              )}
                              {(ord.status === 'ACCEPTED' || ord.status === 'PACKING') && (
                                <button
                                  onClick={() => handleUpdateOrderStatus(ord.id, 'DISPATCHED')}
                                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                                >
                                  Mark Dispatched
                                </button>
                              )}
                              {ord.status === 'DISPATCHED' && (
                                <button
                                  onClick={() => handleUpdateOrderStatus(ord.id, 'DELIVERED')}
                                  className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold"
                                >
                                  Complete Delivery
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                )}

                {/* TAB 2: CATALOG & INVENTORY WITH LIVE QUANTITY STEPPER */}
                {merchantTab === 'catalog' && (
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-800 text-[11px] uppercase text-slate-400 bg-slate-950/60">
                            <th className="py-3.5 px-4">Product Name</th>
                            <th className="py-3.5 px-4">Category</th>
                            <th className="py-3.5 px-4">Price / MRP</th>
                            <th className="py-3.5 px-4">Live Stock Units</th>
                            <th className="py-3.5 px-4">Stock Status</th>
                            <th className="py-3.5 px-4">Storefront Visibility</th>
                            <th className="py-3.5 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800 text-xs">
                          {products
                            .filter((p) => p.storeId === currentTenantStore.id)
                            .map((prod) => (
                              <tr key={prod.id} className="hover:bg-slate-800/40">
                                <td className="py-3.5 px-4 font-semibold text-white">
                                  {prod.name}
                                  <span className="block text-[11px] text-slate-400 font-normal">
                                    Unit: {prod.unit}
                                  </span>
                                </td>
                                <td className="py-3.5 px-4 text-slate-300">{prod.category}</td>
                                <td className="py-3.5 px-4">
                                  <span className="font-bold text-emerald-400">₹{prod.price}</span>{' '}
                                  <span className="text-slate-500 line-through">₹{prod.mrp}</span>
                                </td>
                                <td className="py-3.5 px-4">
                                  <div className="flex items-center gap-2">
                                    <button
                                      onClick={() => handleUpdateProductStockQty(prod.id, -5)}
                                      className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                                    >
                                      -5
                                    </button>
                                    <span className="font-mono font-bold text-white min-w-[28px] text-center">
                                      {prod.stockQty}
                                    </span>
                                    <button
                                      onClick={() => handleUpdateProductStockQty(prod.id, 5)}
                                      className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                                    >
                                      +5
                                    </button>
                                  </div>
                                </td>
                                <td className="py-3.5 px-4">
                                  <button
                                    onClick={() => handleToggleProductStock(prod.id)}
                                    className={`px-2.5 py-1 rounded-lg font-semibold text-[11px] ${
                                      prod.inStock
                                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                    }`}
                                  >
                                    {prod.inStock ? 'In Stock' : 'Out of Stock'}
                                  </button>
                                </td>
                                <td className="py-3.5 px-4">
                                  <button
                                    onClick={() => handleToggleProductVisibility(prod.id)}
                                    className="flex items-center gap-1.5 text-slate-300 hover:text-white"
                                  >
                                    {prod.visible ? (
                                      <>
                                        <Eye className="w-4 h-4 text-emerald-400" />
                                        <span>Visible</span>
                                      </>
                                    ) : (
                                      <>
                                        <EyeOff className="w-4 h-4 text-slate-500" />
                                        <span className="text-slate-500">Hidden</span>
                                      </>
                                    )}
                                  </button>
                                </td>
                                <td className="py-3.5 px-4 text-right">
                                  <button
                                    onClick={() => handleDeleteProduct(prod.id)}
                                    className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400"
                                    title="Delete Product"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 3: DELIVERY RADIUS & STORE PASSWORD SETTINGS */}
                {merchantTab === 'settings' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
                      <h3 className="text-base font-bold text-white">
                        Hyperlocal Delivery Boundary & Store Controls
                      </h3>
                      <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <div>
                          <p className="text-xs font-semibold text-white">Instant Delivery Radius (km)</p>
                          <p className="text-[11px] text-slate-400">
                            Customers within this radius around {currentTenantStore.area} can place instant orders.
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => handleUpdateRadius(currentTenantStore.id, -0.5)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="text-sm font-bold text-indigo-400">
                            {currentTenantStore.radiusKm} km
                          </span>
                          <button
                            onClick={() => handleUpdateRadius(currentTenantStore.id, 0.5)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Change Store Password Card */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                      <div className="flex items-center gap-2 text-indigo-400">
                        <KeyRound className="w-5 h-5" />
                        <h3 className="text-base font-bold text-white">Update Store Login Password</h3>
                      </div>
                      <p className="text-xs text-slate-400">
                        Change the private password for <strong>{currentTenantStore.name}</strong> ({currentTenantStore.loginId}).
                      </p>
                      <form onSubmit={handleChangeMerchantPassword} className="space-y-3 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1">New Store Password</label>
                          <input
                            type="password"
                            required
                            value={newMerchantPassInput}
                            onChange={(e) => setNewMerchantPassInput(e.target.value)}
                            placeholder="Enter new store password"
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                          />
                        </div>
                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                        >
                          Save New Store Password
                        </button>
                      </form>
                    </div>
                  </div>
                )}

                {/* MODAL: ADD PRODUCT */}
                {showAddModal && (
                  <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
                    <form
                      onSubmit={handleCreateProduct}
                      className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="text-base font-bold text-white">
                          Add Product to {currentTenantStore.name}
                        </h3>
                        <button
                          type="button"
                          onClick={() => setShowAddModal(false)}
                          className="text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="space-y-3 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1">Product Title</label>
                          <input
                            type="text"
                            required
                            value={newProduct.name}
                            onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                            placeholder="e.g., Tata Salt Vacuum Evaporated (1 kg)"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-slate-400 mb-1">Selling Price (₹)</label>
                            <input
                              type="number"
                              required
                              value={newProduct.price}
                              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                              placeholder="28"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">MRP (₹)</label>
                            <input
                              type="number"
                              value={newProduct.mrp}
                              onChange={(e) => setNewProduct({ ...newProduct, mrp: e.target.value })}
                              placeholder="30"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-slate-400 mb-1">Category</label>
                            <input
                              type="text"
                              value={newProduct.category}
                              onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">Pack / Unit</label>
                            <input
                              type="text"
                              value={newProduct.unit}
                              onChange={(e) => setNewProduct({ ...newProduct, unit: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setShowAddModal(false)}
                          className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-emerald-600 text-xs font-bold text-white"
                        >
                          Save to Store Catalog
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* =========================================================
            SURFACE 3: RESTRICTED SUPER-ADMIN PORTAL (MASTER PASSWORD PROTECTED)
           ========================================================= */}
        {activeSurface === 'admin' && (
          <div className="space-y-6">
            {!isAdminAuthenticated ? (
              /* SUPER-ADMIN LOGIN GATE */
              <div className="max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5 my-6">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                      Restricted Platform Governance
                    </span>
                    <h2 className="text-base font-bold text-white">Super-Admin Portal Login</h2>
                    <p className="text-xs text-slate-400">
                      Protected by Master Password. Only the platform owner can onboard stores or reset merchant passwords.
                    </p>
                  </div>
                </div>

                <form onSubmit={handleAdminLogin} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Admin Email</label>
                    <input
                      type="email"
                      required
                      value={adminEmailInput}
                      onChange={(e) => setAdminEmailInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Master Password</label>
                    <input
                      type="password"
                      required
                      value={adminPasswordInput}
                      onChange={(e) => setAdminPasswordInput(e.target.value)}
                      placeholder="Enter Master Admin Password"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white"
                    />
                  </div>

                  {adminAuthError && (
                    <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>{adminAuthError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg transition"
                  >
                    Unlock Super-Admin Backoffice
                  </button>
                </form>

                <div
                  onClick={() => {
                    setAdminPasswordInput(adminMasterPassword);
                    setAdminAuthError('');
                  }}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 cursor-pointer flex items-center justify-between text-[11px]"
                >
                  <span className="text-slate-300">🔑 Demo Admin Master Password (Click to Fill):</span>
                  <span className="font-mono font-bold text-amber-400">{adminMasterPassword}</span>
                </div>
              </div>
            ) : (
              /* UNLOCKED SUPER-ADMIN PORTAL */
              <>
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Master Admin Session Active
                    </span>
                    <h2 className="text-lg font-bold text-white">
                      LocalMart Super-Admin Backoffice
                    </h2>
                    <p className="text-xs text-slate-400">
                      Manage merchant onboarding, store credentials, GPS coordinates, subscription billing, and security.
                    </p>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={() => setShowNewStoreModal(true)}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Onboard New Merchant Store</span>
                    </button>
                    <button
                      onClick={() => {
                        setIsAdminAuthenticated(false);
                        showToast('Super-Admin Portal Locked.');
                      }}
                      className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-200 hover:text-rose-300 border border-slate-700 text-xs font-semibold"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Lock Admin</span>
                    </button>
                  </div>
                </div>

                {/* Tenant Store Table with Login ID & Password Reset Controls */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 text-[11px] uppercase text-slate-400 bg-slate-950/60">
                          <th className="py-3.5 px-4">Store & Tenant ID</th>
                          <th className="py-3.5 px-4">Store Login & Password</th>
                          <th className="py-3.5 px-4">GPS Coordinates</th>
                          <th className="py-3.5 px-4">SaaS Plan & Billing</th>
                          <th className="py-3.5 px-4">Platform Status</th>
                          <th className="py-3.5 px-4 text-right">Governance Controls</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-xs">
                        {stores.map((st) => (
                          <tr key={st.id} className="hover:bg-slate-800/40">
                            <td className="py-3.5 px-4">
                              <p className="font-bold text-white">{st.name}</p>
                              <p className="text-[11px] text-slate-400">
                                {st.owner} • <span className="font-mono">{st.id}</span>
                              </p>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className="block font-mono text-slate-200 text-[11px]">{st.loginId}</span>
                              <span className="inline-block mt-0.5 font-mono text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-300">
                                Pass: {st.password}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-slate-300 font-mono text-[11px]">
                              {st.lat.toFixed(4)}, {st.lng.toFixed(4)}
                              <span className="block text-[10px] text-slate-400">{st.area}</span>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className="block text-slate-200 font-medium">{st.plan}</span>
                              <span
                                className={`inline-block mt-0.5 text-[10px] font-bold px-2 py-0.5 rounded ${
                                  st.billingStatus === 'Paid'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : 'bg-amber-500/20 text-amber-300'
                                }`}
                              >
                                {st.billingStatus}
                              </span>
                            </td>
                            <td className="py-3.5 px-4">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                                  st.isActive
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : 'bg-rose-500/20 text-rose-300'
                                }`}
                              >
                                {st.isActive ? 'ACTIVE' : 'SUSPENDED'}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                              <button
                                onClick={() => {
                                  setResetPassStoreId(st.id);
                                  setResetPassValue(st.password);
                                }}
                                className="px-2.5 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 text-[11px] font-semibold"
                              >
                                Set Password
                              </button>
                              <button
                                onClick={() => handleForceLogoutStore(st.id)}
                                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium"
                              >
                                Force Logout
                              </button>
                              <button
                                onClick={() => handleToggleStoreActive(st.id)}
                                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold ${
                                  st.isActive
                                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                }`}
                              >
                                {st.isActive ? 'Deactivate' : 'Activate'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Master Admin Password Update Section */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-md space-y-3">
                  <div className="flex items-center gap-2 text-amber-400">
                    <KeyRound className="w-4 h-4" />
                    <h3 className="text-sm font-bold text-white">Change Super-Admin Master Password</h3>
                  </div>
                  <form onSubmit={handleChangeAdminPassword} className="flex gap-2 text-xs">
                    <input
                      type="password"
                      required
                      value={newAdminPassInput}
                      onChange={(e) => setNewAdminPassInput(e.target.value)}
                      placeholder="New Master Password"
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                    >
                      Update
                    </button>
                  </form>
                </div>

                {/* MODAL: RESET MERCHANT PASSWORD */}
                {resetPassStoreId && (
                  <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
                    <form
                      onSubmit={handleAdminResetStorePassword}
                      className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-sm space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white">Set Storefront Password</h3>
                        <button
                          type="button"
                          onClick={() => setResetPassStoreId(null)}
                          className="text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-slate-400">
                        Assign a new login password for{' '}
                        <strong className="text-white">
                          {stores.find((s) => s.id === resetPassStoreId)?.name}
                        </strong>
                        .
                      </p>
                      <input
                        type="text"
                        required
                        value={resetPassValue}
                        onChange={(e) => setResetPassValue(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setResetPassStoreId(null)}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs"
                        >
                          Save Password
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {/* MODAL: ONBOARD NEW MERCHANT WITH LOGIN & PASSWORD */}
                {showNewStoreModal && (
                  <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
                    <form
                      onSubmit={handleOnboardStore}
                      className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md space-y-4 max-h-[90vh] overflow-y-auto"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="text-base font-bold text-white">Onboard New Kanpur Storefront</h3>
                        <button
                          type="button"
                          onClick={() => setShowNewStoreModal(false)}
                          className="text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="space-y-3 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1">Storefront Name</label>
                          <input
                            type="text"
                            required
                            value={newStoreForm.name}
                            onChange={(e) => setNewStoreForm({ ...newStoreForm, name: e.target.value })}
                            placeholder="e.g., Govind Nagar Super Mart"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-slate-400 mb-1">Owner Name</label>
                            <input
                              type="text"
                              required
                              value={newStoreForm.owner}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, owner: e.target.value })}
                              placeholder="Rajesh Mishra"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">Phone</label>
                            <input
                              type="text"
                              value={newStoreForm.phone}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, phone: e.target.value })}
                              placeholder="+91 98390 12345"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-indigo-400 font-semibold mb-1">Store Login ID</label>
                            <input
                              type="text"
                              required
                              value={newStoreForm.loginId}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, loginId: e.target.value })}
                              placeholder="govind@localmart.in"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-indigo-400 font-semibold mb-1">Store Password</label>
                            <input
                              type="text"
                              required
                              value={newStoreForm.password}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, password: e.target.value })}
                              placeholder="govind123"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-slate-400 mb-1">Kanpur Locality</label>
                            <input
                              type="text"
                              value={newStoreForm.area}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, area: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">Pincode</label>
                            <input
                              type="text"
                              value={newStoreForm.pincode}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, pincode: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-slate-400 mb-1">Latitude</label>
                            <input
                              type="text"
                              value={newStoreForm.lat}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, lat: e.target.value })}
                              placeholder="26.4784"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1">Longitude</label>
                            <input
                              type="text"
                              value={newStoreForm.lng}
                              onChange={(e) => setNewStoreForm({ ...newStoreForm, lng: e.target.value })}
                              placeholder="80.3205"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setShowNewStoreModal(false)}
                          className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-amber-500 text-xs font-bold text-slate-950"
                        >
                          Provision Store Tenant
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
