# LocalMart — Multi-Store Hyperlocal Quick-Commerce & Instant Delivery SaaS

Production-ready full-stack project configured for **1-click Vercel deployment** (Vite + React + Tailwind CSS + PWA Frontend + Python FastAPI Serverless Backend).

---

## Project Structure

```text
localmart-vercel/
├── api/
│   └── index.py             # Python FastAPI Serverless Backend (Geofencing, Auth, Multi-Tenant API)
├── public/
│   ├── icon.svg             # Scalable App Icon (192x192 / 512x512)
│   ├── manifest.json        # Chrome & Mobile PWA Web App Manifest ("Add to Home Screen")
│   └── sw.js                # Service Worker for Offline Caching & Standalone App Mode
├── src/
│   ├── App.jsx              # 3-in-1 Multi-Tenant Application (Customer App + Shopkeeper Web + Admin Portal)
│   ├── index.css            # Tailwind CSS Directives
│   └── main.jsx             # React 18 Root Entrypoint
├── .env.example             # Environment Variable Template for Vercel & Turso Cloud
├── .gitignore               # Git Ignore Rules
├── index.html               # Mobile-First HTML Entry with PWA & Service Worker Registration
├── package.json             # Node Dependencies & Build Scripts (Vite + React + Tailwind + Lucide)
├── postcss.config.js        # PostCSS Configuration
├── requirements.txt         # Python Dependencies for Vercel Serverless Runtime (FastAPI, Pydantic)
├── tailwind.config.js       # Tailwind CSS Configuration
├── vercel.json              # Vercel Build, Routing & Serverless API Rewrite Configuration
└── vite.config.js           # Vite Production Build & Local API Proxy Configuration
```

---

## Default Credentials (Pre-Configured for Testing)

### 1. Shopkeeper Partner Logins (Isolated Per Storefront)
* **Gupta Kirana & General Store (Swaroop Nagar):**
  * **Login ID:** `gupta@localmart.in`
  * **Password:** `gupta123`
* **Kanpur Fresh Dairy & Bakery (Kakadeo):**
  * **Login ID:** `dairy@localmart.in`
  * **Password:** `dairy123`
* **Nayaganj Spice & Dry Fruit Hub (Kidwai Nagar):**
  * **Login ID:** `spice@localmart.in`
  * **Password:** `spice123`

*(Note: Each shopkeeper can change their password inside **Shopkeeper Web -> Radius & Password Security**, or the Super-Admin can reset any store's password.)*

### 2. Super-Admin Backoffice Portal
* **Admin Email:** `admin@localmart.in`
* **Master Password:** `admin@kanpur2026`

---

## How to Deploy to Vercel (Step-by-Step)

### Option A: Deploy via GitHub & Vercel Dashboard (Recommended)
1. Unzip `localmart-vercel-production.zip` on your computer.
2. Push this folder to a new GitHub repository.
3. Log in to [Vercel](https://vercel.com/new) and click **Import** next to your repository.
4. Vercel will automatically detect **Vite** from `vercel.json`:
   * **Build Command:** `npm run build`
   * **Output Directory:** `dist`
5. Click **Deploy**. In ~45 seconds, you will get a live HTTPS URL (e.g., `https://localmart-kanpur.vercel.app`).

### Option B: Deploy Directly from Terminal (Vercel CLI)
```bash
npm install
npx vercel --prod
```

---

## Installing as a Mobile / Counter App (PWA)
1. Open your deployed HTTPS Vercel link in **Google Chrome** on any Android phone, iPhone, or counter tablet.
2. Tap the **Chrome menu (⋮)** in the top-right corner and select **"Add to Home screen"** (or **"Install app"**).
3. LocalMart installs onto the home screen and launches in full-screen standalone mode with live satellite GPS pinpointing and repeating Web Audio counter alarms for incoming orders.
