"""LocalMart Multi-Tenant FastAPI Backend for Vercel Serverless Functions.

Compatible with Vercel Python runtime (`api/index.py`) and local `uvicorn api.index:app --reload`.
Uses SQLite (`/tmp/localmart.db` in Vercel serverless environment) or `TURSO_DATABASE_URL` when configured.
"""

import math
import os
import random
import sqlite3
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(
    title="LocalMart Multi-Store Quick-Commerce API",
    version="1.0.0",
    description="Multi-tenant backend with Haversine geofencing, per-store password isolation, and 5-stage order pipeline."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = os.environ.get("LOCALMART_DB_PATH", "/tmp/localmart.db")
ADMIN_MASTER_PASSWORD = os.environ.get("ADMIN_MASTER_PASSWORD", "admin@kanpur2026")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS stores (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            owner TEXT NOT NULL,
            phone TEXT,
            login_id TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            area TEXT,
            pincode TEXT,
            lat REAL,
            lng REAL,
            radius_km REAL DEFAULT 3.5,
            is_open INTEGER DEFAULT 1,
            is_active INTEGER DEFAULT 1,
            plan TEXT,
            billing_status TEXT DEFAULT 'Paid',
            free_delivery_threshold INTEGER DEFAULT 199
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            store_id TEXT NOT NULL,
            name TEXT NOT NULL,
            category TEXT,
            price INTEGER NOT NULL,
            mrp INTEGER NOT NULL,
            unit TEXT,
            in_stock INTEGER DEFAULT 1,
            visible INTEGER DEFAULT 1,
            stock_qty INTEGER DEFAULT 25,
            FOREIGN KEY (store_id) REFERENCES stores(id)
        )
        """
    )
    conn.commit()
    conn.close()


init_db()


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(math.radians(lat1))
        * math.cos(math.radians(lat2))
        * math.sin(dlon / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(r * c, 2)


class MerchantLoginRequest(BaseModel):
    store_id: str
    password: str


class AdminLoginRequest(BaseModel):
    email: str
    password: str


class GeolocationCheckRequest(BaseModel):
    customer_lat: float
    customer_lng: float
    store_lat: float
    store_lng: float
    radius_km: float


@app.get("/api/health")
def health_check():
    return {
        "status": "ok",
        "service": "LocalMart Multi-Tenant SaaS API",
        "database": DB_PATH,
    }


@app.post("/api/geofence/check")
def check_geofence(req: GeolocationCheckRequest):
    distance_km = haversine_km(
        req.customer_lat, req.customer_lng, req.store_lat, req.store_lng
    )
    return {
        "distance_km": distance_km,
        "radius_km": req.radius_km,
        "is_within_radius": distance_km <= req.radius_km,
    }


@app.post("/api/auth/admin")
def admin_login(req: AdminLoginRequest):
    if req.password != ADMIN_MASTER_PASSWORD:
        raise HTTPException(status_code=401, detail="Invalid Master Password")
    return {
        "authenticated": True,
        "role": "SUPER_ADMIN",
        "email": req.email,
    }
